import Foundation

//exercise 1

func evenNumb(number: Int) -> Bool { number % 2 == 0}


//exercise 2

func partibility(_ number: Int) -> Bool { number % 3 == 0}


//exercise 3

//var newArray = [1...100]
var newArray = [Int]()

for i in 1...100 {
    newArray.append(i)
}

//exercise 4

for item in newArray {
    if evenNumb(number: item) || !partibility(item ) {
        if let index = newArray.firstIndex(of: item) {
            newArray.remove(at: index)
        }
    }
}

print(newArray)
