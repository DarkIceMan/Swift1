import Foundation

//Exercise 1

let a: Double = 1
let b: Double = -7
let c: Double = 3
var x1: Double
var x2: Double
let discriminant = (b * b) - (4 * a * c)

if discriminant > 0 {
    x1 = (-b + sqrt(discriminant)) / (2 * a)
    x2 = (-b - sqrt(discriminant)) / (2 * a)
    print("x1 = \(x1)")
    print("x2 = \(x2)")
}
else if discriminant == 0 {
    x1 = (-b + sqrt(discriminant)) / (2 * a)
    print("x1,x2 = \(x1)")
}
else {
    print("There is no decision")
}

//Exercise 2

let sideA: Double = 3
let sideB: Double = 4
let sideC: Double = sqrt(a * a + b * b)
let perimetr = sideA + sideB + sideC
let square = sideA * sideB / 2

print("Hypotenuse = \(sideC)")
print("Perimetr = \(perimetr)")
print("Square = \(square)")


